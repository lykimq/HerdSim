HerdSim Phase 1 size map -- standalone English package
======================================================

How to read:
  Open index.html (or REPORT_en.html) in any web browser.
  No git repository, server, or internet connection is required.

Contents:
  index.html    Landing page.
  REPORT_en.html The full report (plan, runs, results, claims) with figures.
  assets/       Figures (PNG) and data tables (CSV) that the report links to.

The Vietnamese report is separate and is not part of this package.
